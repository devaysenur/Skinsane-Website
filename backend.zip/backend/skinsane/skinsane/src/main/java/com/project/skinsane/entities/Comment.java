package com.project.skinsane.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Column;
import lombok.Data;


@Entity
@Table(name="comment")
@Data
public class Comment {
    @Id
    Long id;
    Long postId;
    Long userId;

    @Lob
    @Column (columnDefinition="text") /*varchar 255 almasın diye*/
    String text;
}
