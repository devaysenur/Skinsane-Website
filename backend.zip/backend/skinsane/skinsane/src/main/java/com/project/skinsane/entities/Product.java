package com.project.skinsane.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Table(name="product")
@Data

public class Product {
    @Id
    Long id;
    String productName;
    String productInfo;


}
