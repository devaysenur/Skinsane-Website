package com.project.skinsane.controllers;

import com.project.skinsane.entities.User;
import com.project.skinsane.repos.UserRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users") /*ana mapping bu. users içerenlerin hepsine bu hitap ediyor*/
public class UserController {
    private UserRepository userRepository;

    public UserController(UserRepository userRepository) { //contstructer injection yaptım
        this.userRepository=userRepository;
    }

    @GetMapping //getirmek için
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @PostMapping //bir şeyler create etmek için
    public User createUser(@RequestBody User newUser){ //gelen user bilgisini newUsera maple
        return userRepository.save(newUser); //dbye save et
    }

    @GetMapping("/{userId}") //req.map'teki users'a append eder (ucuna ekler)
    public User getOneUser(@PathVariable Long userId){
        //custom exception ekle
        return userRepository.findById(userId).orElse(null);
    }
    //varolan id'li bir user'ı değiştirmek için
    @PutMapping("/{userId}")
    public User updateOneUser(@PathVariable Long userId, @RequestBody User newUser) {
        //update etmek için önce o repositoryden userı bulmamız lazım
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) { //optionalda is present objeyi buldu demektir
            User foundUser =user.get();
            foundUser.setUserName(newUser.getUserName());
            foundUser.setPassword(newUser.getPassword());
            userRepository.save(foundUser);
            return foundUser;
        }else
            return null;
    }

    @DeleteMapping("/{userId}")
    public void deleteOneUser(@PathVariable Long userId){
        userRepository.deleteById(userId);
    }
}

