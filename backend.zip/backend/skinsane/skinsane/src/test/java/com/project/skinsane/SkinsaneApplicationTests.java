package com.project.skinsane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkinsaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
